﻿using Guna.UI2.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace thanhtoan
{
    public partial class Form1 : Form
    {
         

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            uC_dichvu1.Visible = false;
            uC_CheckOut1. Visible = false;
            history1.Visible = false;
            dichvu.PerformClick(); 
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            uC_CheckOut1.Visible = true;
            uC_CheckOut1.BringToFront();

        }

        private void button6_Click(object sender, EventArgs e)
        {
            history1.Visible = true;
            history1.BringToFront();
        }

        private void dichvu_Click(object sender, EventArgs e)
        {
                uC_dichvu1.Visible = true;
            uC_dichvu1.BringToFront();
        }

        private void uC_dichvu1_Load(object sender, EventArgs e)
        {

        }
        private void LoadRoomData()
        {
            // Câu lệnh SQL để lấy các phòng đã thanh toán
            string query = "SELECT * FROM [dbo].[rooms] WHERE booked = 'YES'";

            // Sử dụng function để lấy dữ liệu
            function fn = new function();
            DataSet ds = fn.getData(query);

            // Gán dữ liệu từ DataSet vào DataGridView
            guna2DataGridView1.DataSource = ds.Tables[0];  // Gán dữ liệu vào DataGridView
        }
    }
}
