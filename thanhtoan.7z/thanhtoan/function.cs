﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;
using Microsoft.Build.Tasks;

namespace thanhtoan
{
    class function
    {
        protected SqlConnection getConnection()
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\Dell-PC\\OneDrive\\Tài liệu\\dichvuandthanhtoan.mdf;Integrated Security=True;Connect Timeout=30";
            return con;
        }


        public DataSet getData(string query)
        {

            SqlConnection connection = getConnection();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = connection;
            cmd.CommandText = query;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;
        }



        public void setData(String  query, String messager) 
        { 
            SqlConnection con = getConnection();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            con.Open();
            cmd.CommandText = query;
            cmd.ExecuteNonQuery();
            con.Close();


            MessageBox.Show(messager, "success" , MessageBoxButtons.OK, MessageBoxIcon.Information);

            
        }

        public SqlDataReader getForCombo(String query)
        {
            SqlConnection con = getConnection();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            con.Open();
            cmd = new SqlCommand(query , con);
            SqlDataReader sdr = cmd.ExecuteReader();
            return sdr;
        }
        public void setDataWithParams(SqlCommand cmd, string message)
        {
            SqlConnection con = getConnection();
            cmd.Connection = con;

            try
            {
                con.Open();
                cmd.ExecuteNonQuery(); // Thực thi câu lệnh SQL
                MessageBox.Show(message, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                con.Close(); // Đảm bảo đóng kết nối sau khi thực thi
            }
        }
        public void UpdateRoomStatus(string roomNo, string status)
        {
            // Câu lệnh SQL để cập nhật trạng thái phòng
            string query = "UPDATE [dbo].[rooms] SET booked = @status WHERE roomNo = @roomNo";

            using (SqlConnection con = getConnection())
            {
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@status", status);  // Trạng thái, ví dụ: 'YES'
                    cmd.Parameters.AddWithValue("@roomNo", roomNo);  // Mã phòng, ví dụ: '101'

                    try
                    {
                        con.Open();
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Thanh toán thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Lỗi khi cập nhật trạng thái phòng: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    finally
                    {
                        con.Close();  // Đảm bảo đóng kết nối
                    }
                }
            }
        }



    }
}
