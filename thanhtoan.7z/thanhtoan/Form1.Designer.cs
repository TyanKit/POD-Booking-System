﻿namespace thanhtoan
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.backgroundWorker2 = new System.ComponentModel.BackgroundWorker();
            this.panel2 = new System.Windows.Forms.Panel();
            this.diemthuong = new System.Windows.Forms.Button();
            this.lichsu = new System.Windows.Forms.Button();
            this.thanhtoan = new System.Windows.Forms.Button();
            this.dichvu = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.uC_CheckOut1 = new thanhtoan.all_user_control.UC_CheckOut();
            this.uC_dichvu1 = new thanhtoan.all_user_control.UC_dichvu();
            this.backgroundWorker3 = new System.ComponentModel.BackgroundWorker();
            this.minisize = new System.Windows.Forms.Button();
            this.exit = new System.Windows.Forms.Button();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Elipse2 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Elipse3 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Elipse4 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.history1 = new thanhtoan.all_user_control.History();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.diemthuong);
            this.panel2.Controls.Add(this.lichsu);
            this.panel2.Controls.Add(this.thanhtoan);
            this.panel2.Controls.Add(this.dichvu);
            this.panel2.Location = new System.Drawing.Point(113, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1505, 162);
            this.panel2.TabIndex = 3;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // diemthuong
            // 
            this.diemthuong.Font = new System.Drawing.Font("Segoe UI Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.diemthuong.Location = new System.Drawing.Point(1139, 27);
            this.diemthuong.Name = "diemthuong";
            this.diemthuong.Size = new System.Drawing.Size(284, 116);
            this.diemthuong.TabIndex = 2;
            this.diemthuong.Text = "điểm thưởng";
            this.diemthuong.UseVisualStyleBackColor = true;
            // 
            // lichsu
            // 
            this.lichsu.Font = new System.Drawing.Font("Segoe UI Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lichsu.Location = new System.Drawing.Point(777, 27);
            this.lichsu.Name = "lichsu";
            this.lichsu.Size = new System.Drawing.Size(284, 116);
            this.lichsu.TabIndex = 3;
            this.lichsu.Text = "Lịch Sử";
            this.lichsu.UseVisualStyleBackColor = true;
            this.lichsu.Click += new System.EventHandler(this.button6_Click);
            // 
            // thanhtoan
            // 
            this.thanhtoan.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.thanhtoan.Font = new System.Drawing.Font("Segoe UI Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.thanhtoan.Location = new System.Drawing.Point(404, 27);
            this.thanhtoan.Name = "thanhtoan";
            this.thanhtoan.Size = new System.Drawing.Size(284, 116);
            this.thanhtoan.TabIndex = 1;
            this.thanhtoan.Text = "thanh toán";
            this.thanhtoan.UseVisualStyleBackColor = true;
            this.thanhtoan.Click += new System.EventHandler(this.button4_Click);
            // 
            // dichvu
            // 
            this.dichvu.Font = new System.Drawing.Font("Segoe UI Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dichvu.Location = new System.Drawing.Point(47, 27);
            this.dichvu.Name = "dichvu";
            this.dichvu.Size = new System.Drawing.Size(284, 116);
            this.dichvu.TabIndex = 0;
            this.dichvu.Text = "dịch vụ";
            this.dichvu.UseVisualStyleBackColor = true;
            this.dichvu.Click += new System.EventHandler(this.dichvu_Click);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.history1);
            this.panel1.Controls.Add(this.uC_CheckOut1);
            this.panel1.Controls.Add(this.uC_dichvu1);
            this.panel1.Location = new System.Drawing.Point(12, 193);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1695, 852);
            this.panel1.TabIndex = 4;
            // 
            // uC_CheckOut1
            // 
            this.uC_CheckOut1.BackColor = System.Drawing.Color.AliceBlue;
            this.uC_CheckOut1.Location = new System.Drawing.Point(-23, -2);
            this.uC_CheckOut1.Name = "uC_CheckOut1";
            this.uC_CheckOut1.Size = new System.Drawing.Size(1882, 852);
            this.uC_CheckOut1.TabIndex = 1;
            // 
            // uC_dichvu1
            // 
            this.uC_dichvu1.BackColor = System.Drawing.Color.GhostWhite;
            this.uC_dichvu1.Location = new System.Drawing.Point(-2, 4);
            this.uC_dichvu1.Name = "uC_dichvu1";
            this.uC_dichvu1.Size = new System.Drawing.Size(1506, 852);
            this.uC_dichvu1.TabIndex = 0;
            this.uC_dichvu1.Load += new System.EventHandler(this.uC_dichvu1_Load);
            // 
            // minisize
            // 
            this.minisize.Image = global::thanhtoan.Properties.Resources.minimize_window_25pxdf;
            this.minisize.Location = new System.Drawing.Point(12, 84);
            this.minisize.Name = "minisize";
            this.minisize.Size = new System.Drawing.Size(57, 60);
            this.minisize.TabIndex = 1;
            this.minisize.UseVisualStyleBackColor = true;
            this.minisize.Click += new System.EventHandler(this.button2_Click);
            // 
            // exit
            // 
            this.exit.Image = global::thanhtoan.Properties.Resources.cancel_25px;
            this.exit.Location = new System.Drawing.Point(12, 12);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(57, 60);
            this.exit.TabIndex = 0;
            this.exit.UseVisualStyleBackColor = true;
            // 
            // guna2Elipse2
            // 
            this.guna2Elipse2.TargetControl = this;
            // 
            // guna2Elipse4
            // 
            this.guna2Elipse4.TargetControl = this;
            // 
            // history1
            // 
            this.history1.BackColor = System.Drawing.Color.MintCream;
            this.history1.Location = new System.Drawing.Point(-2, -2);
            this.history1.Name = "history1";
            this.history1.Size = new System.Drawing.Size(1882, 852);
            this.history1.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cyan;
            this.ClientSize = new System.Drawing.Size(1844, 752);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.minisize);
            this.Controls.Add(this.exit);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.ComponentModel.BackgroundWorker backgroundWorker2;
        private System.Windows.Forms.Button exit;
        private System.Windows.Forms.Button minisize;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button dichvu;
        private System.Windows.Forms.Button diemthuong;
        private System.Windows.Forms.Button lichsu;
        private System.Windows.Forms.Button thanhtoan;
        private System.ComponentModel.BackgroundWorker backgroundWorker3;
        private all_user_control.UC_dichvu uC_dichvu1;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse2;
        private all_user_control.UC_CheckOut uC_CheckOut1;
        public Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse3;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse4;
        private all_user_control.History history1;
    }
}

