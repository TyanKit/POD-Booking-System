﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace thanhtoan.all_user_control
{
    public partial class UC_dichvu : UserControl
    {
        function fn = new function();
        String query;
        public UC_dichvu()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtroomno.Text != "" && txtroomtype.Text != "" && txtprice.Text != "")
            {
                String roomno = txtroomno.Text;
                String type = txtroomtype.Text;
                Int64 price = Int64.Parse(txtprice.Text);


                query = "insert into rooms (roomno, roomtype, price ) values ('"+ roomno+"','"+ type+"',"+ price+")";
                fn.setData(query, "Đã Thêm Phòng");


                UC_dichvu_Load(this, null);
                clearAll();
            }else
            {
                MessageBox.Show(" Xin vui lòng điền đầy đủ thông tin","Warning !",MessageBoxButtons.OK, MessageBoxIcon.Warning );
            }
        }
        public void clearAll()
        {
            txtroomno.Clear();
            txtroomtype.SelectedIndex = -1;
            txtprice.Clear();
        }

        private void UC_dichvu_Load(object sender, EventArgs e)
        {
            query = "select * from rooms";
            DataSet ds = fn.getData(query);
            dataGridView1.DataSource = ds.Tables[0] ;
        }

        private void textBox2_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void UC_dichvu_Leave(object sender, EventArgs e)
        {
            clearAll();
        }

        private void UC_dichvu_Enter(object sender, EventArgs e)
        {
            UC_dichvu_Load(this, null);
        }
    }
}
