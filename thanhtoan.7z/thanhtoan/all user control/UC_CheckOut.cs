﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static thanhtoan.all_user_control.History;

namespace thanhtoan.all_user_control
{
    public partial class UC_CheckOut : UserControl
    {
        function fn = new function();
        String query;
        public UC_CheckOut()
        {
            InitializeComponent();
        }
        public void LoadDataFromDatabase()
        {
            try
            {
                string query = "SELECT roomno, roomtype, price, isPaid FROM rooms"; // Lấy các thông tin từ bảng rooms
                DataSet ds = fn.getData(query); // Gọi phương thức getData trong class function để lấy dữ liệu
                guna2DataGridView1.DataSource = ds.Tables[0]; // Cập nhật dữ liệu vào DataGridView
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi tải dữ liệu: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void UC_CheckOut_Load(object sender, EventArgs e)
        {

            query = "SELECT * FROM rooms";
            DataSet ds = fn.getData(query);

            if (ds.Tables[0].Rows.Count > 0) 
            {
                guna2DataGridView1.DataSource = ds.Tables[0]; 
            }
            else
            {
                MessageBox.Show("Không có dữ liệu để hiển thị!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {

            if (!string.IsNullOrEmpty(txtName.Text))
            {
               
                query = "SELECT * FROM rooms WHERE roomno LIKE '%" + txtName.Text + "%' OR roomtype LIKE '%" + txtName.Text + "%'";
            }
            else
            {
                
                query = "SELECT * FROM rooms";
            }

            DataSet ds = fn.getData(query);
            guna2DataGridView1.DataSource = ds.Tables[0];
        }

        private void dataGridView2(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnCheckOut_Click(object sender, EventArgs e)
        {
            // Giả sử bạn lấy mã phòng từ TextBox hoặc DataGridView
            string roomNo = txtRoomNo.Text;  // Lấy mã phòng từ textbox
            string status = "YES";  // Đặt trạng thái là 'YES' sau khi thanh toán

            // Gọi phương thức UpdateRoomStatus để cập nhật trạng thái phòng
            function fn = new function();
            fn.UpdateRoomStatus(roomNo, status);

            // Nếu bạn muốn hiển thị lại danh sách phòng sau khi thanh toán
            LoadRoomData(); // Tải lại dữ liệu phòng (có thể hiển thị bảng với các phòng đã thanh toán)
            // Kiểm tra xem người dùng đã chọn phòng trong DataGridView chưa
            if (guna2DataGridView1.SelectedRows.Count > 0)
            {
                try
                {
                    // Lấy thông tin phòng từ hàng đã chọn trong DataGridView
                    string roomno = guna2DataGridView1.SelectedRows[0].Cells["roomno"].Value.ToString();
                    string type = guna2DataGridView1.SelectedRows[0].Cells["roomtype"].Value.ToString();
                    decimal price = Convert.ToDecimal(guna2DataGridView1.SelectedRows[0].Cells["price"].Value);

                    // Lưu thông tin phòng đã thanh toán vào danh sách
                    PaymentHistory paymentHistory = new PaymentHistory
                    {
                        RoomNo = roomno,
                        RoomType = type,
                        Price = price,
                        PaymentDate = DateTime.Now
                    };

                    paymentHistoryList.Add(paymentHistory);

                    // Hiển thị thông báo thanh toán thành công
                    MessageBox.Show($"Phòng {roomno} ({type}) đã thanh toán thành công với giá {price} VND.", "Thanh toán thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // Cập nhật lại DataGridView để hiển thị thông tin đã thanh toán
                    LoadHistoryData();  // Hiển thị lịch sử thanh toán trong DataGridView
                }
                catch (Exception ex)
                {
                    // Hiển thị lỗi nếu có vấn đề xảy ra
                    MessageBox.Show("Lỗi: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Vui lòng chọn phòng cần thanh toán.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
