﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace thanhtoan.all_user_control
{
    public partial class History : UserControl
    {
        public class PaymentHistory
        {
            public string RoomNo { get; set; }
            public string RoomType { get; set; }
            public decimal Price { get; set; }
            public DateTime PaymentDate { get; set; }
        }

        // Khai báo danh sách lưu trữ các phòng đã thanh toán
        List<PaymentHistory> paymentHistoryList = new List<PaymentHistory>();

        public void LoadHistoryData()
        {
            // Tạo một DataTable để chứa dữ liệu hiển thị trong DataGridView
            DataTable dt = new DataTable();
            dt.Columns.Add("RoomNo");
            dt.Columns.Add("RoomType");
            dt.Columns.Add("Price");
            dt.Columns.Add("PaymentDate");

            // Lặp qua danh sách paymentHistoryList để thêm các dữ liệu vào DataTable
            foreach (var payment in paymentHistoryList)
            {
                dt.Rows.Add(payment.RoomNo, payment.RoomType, payment.Price, payment.PaymentDate);
            }

            // Cập nhật DataGridView3 với dữ liệu đã có trong DataTable
            DataGridView3.DataSource = dt;
        }
        public History()
        {
            InitializeComponent();
        }
        
        private void DataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
